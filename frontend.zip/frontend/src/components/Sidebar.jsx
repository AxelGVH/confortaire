import { useSidebar } from '../context/SidebarContext';
import { NavLink } from 'react-router-dom';
import { Home, Settings, UserCheck } from 'react-feather'; // ⬅️ Import your icons

export default function Sidebar() {
  const { isOpen } = useSidebar();

  return (
    <div
      className={`${
        isOpen ? 'block' : 'hidden'
      } md:block w-64 bg-white border-r border-gray-200 min-h-full p-4 fixed md:static z-20`}
    >
      <nav className="flex flex-col space-y-2">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `flex items-center space-x-2 px-4 py-2 rounded ${
              isActive ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <Home size={18} />
          <span>Dashboard</span>
        </NavLink>

        <NavLink
          to="/ListVendors"
          className={({ isActive }) =>
            `flex items-center space-x-2 px-4 py-2 rounded ${
              isActive ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <UserCheck size={18} />
          <span>Vendors</span>
        </NavLink>
      </nav>
      <NavLink
        to="/admin"
        className={({ isActive }) =>
          `flex items-center space-x-2 px-4 py-2 rounded ${
            isActive ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100'
          }`
        }
      >
        <Settings size={18} />
        <span>Admin Panel</span>
      </NavLink>

  
    </div>
  );
}
